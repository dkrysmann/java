package app;

import app.models.strategies.RecyclableGarbageStrategy;
import app.models.strategies.StorableGarbageStrategy;
import app.models.wastes.BurnableGarbage;
import app.models.strategies.BurnableGarbageDisposalStrategy;
import app.models.wastes.RecyclableGarbage;
import app.models.wastes.StorableGarbage;
import app.waste_disposal.DefaultGarbageProcessor;
import app.waste_disposal.annotations.Burnable;
import app.waste_disposal.annotations.Recyclable;
import app.waste_disposal.annotations.Storable;
import app.waste_disposal.contracts.GarbageProcessor;
import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;

public class Main {
    public static void main(String[] args) {
        double energyBalance = 0.0;
        double capital = 0.0;
        GarbageProcessor garbageProcessor = new DefaultGarbageProcessor();
        addStragies(garbageProcessor);
        Waste wood = new BurnableGarbage("Wood", 33.156, 3.657);
        Waste glass = new RecyclableGarbage("Glass", 10, 1.14);
        Waste bottles = new StorableGarbage("UsedShampooBottles", 2.25, 1.57);

        ProcessingData woodData = garbageProcessor.processWaste(wood);
        ProcessingData glassData = garbageProcessor.processWaste(glass);
        ProcessingData bottlesData = garbageProcessor.processWaste(bottles);
        energyBalance += woodData.getEnergyBalance() + glassData.getEnergyBalance() + bottlesData.getEnergyBalance();
        capital += woodData.getCapitalBalance() + glassData.getCapitalBalance() + bottlesData.getCapitalBalance();
        System.out.println(energyBalance);
        System.out.println(capital);
    }

    private static void addStragies(GarbageProcessor garbageProcessor) {
        garbageProcessor.getStrategyHolder().addStrategy(Burnable.class,new BurnableGarbageDisposalStrategy());
        garbageProcessor.getStrategyHolder().addStrategy(Recyclable.class,new RecyclableGarbageStrategy());
        garbageProcessor.getStrategyHolder().addStrategy(Storable.class,new StorableGarbageStrategy());
    }
}
