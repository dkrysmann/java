package ClassBox;


public class Box {
    private double lenght;
    private double width;
    private double height;

    public Box(double lenght,double width,double height){
        this.height = height;
        this.width = width;
        this.lenght = lenght;
    }
    private double getLenght(){
        return this.lenght;
    }
    private double getWidth(){
        return this.width;
    }
    private double getHeight(){
        return this.height;
    }
   private double printSurfaceArea(){
       return (2*this.getLenght() * this.getWidth()) +
               (2*this.getLenght() * this.getHeight()) +
               (2*this.getWidth() * this.getHeight());
   }
   private double printLateralSurfaceArea(){
       return (2*this.getLenght()*this.getHeight() + 2*this.getWidth()*this.getHeight());
   }
   private double printVolume(){
       return this.getLenght()*this.getWidth()*this.getHeight();
   }
   public void printResult(){
       System.out.printf("Surface Area - %.2f%n",this.printSurfaceArea());
       System.out.printf("Lateral Surface Area - %.2f%n",this.printLateralSurfaceArea());
       System.out.printf("Volume - %.2f",this.printVolume());
   }
}
