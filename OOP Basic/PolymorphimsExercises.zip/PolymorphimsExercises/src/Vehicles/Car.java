package Vehicles;


public class Car extends Vehicle{
    public Car(double fuelQuantity,double fuelConsumation){
        super(fuelQuantity,fuelConsumation);
    }
}
