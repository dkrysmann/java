package Vehicles;


public class Truck extends Vehicle{
    public Truck(double fuelQuantity,double fuelConsumation){
        super(fuelQuantity,fuelConsumation);
    }
}
