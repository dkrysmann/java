package StackOfStrings;


public class Main {
    public static void main(String[] args) {
        StackOfStrings sos = new StackOfStrings();
        sos.push("klqnko");
        sos.push("gosho");
        sos.push("Pesho");
        sos.push("adamas");
        System.out.println(sos.pop());
        System.out.println(sos.pop());
        System.out.println(sos.pop());
        System.out.println(sos.pop());
    }
}
