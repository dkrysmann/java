package FragileBaseClass;


public class Food {

}
