package HierarchicalInherirance;


public class Cat extends Animal{
    public void meow(){
        System.out.println("meowing...");
    }
}
