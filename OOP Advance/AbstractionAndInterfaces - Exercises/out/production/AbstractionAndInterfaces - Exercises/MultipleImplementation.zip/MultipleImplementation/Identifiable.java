package MultipleImplementation;


public interface Identifiable {
    String getId();
}
