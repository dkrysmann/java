package Telephony;


public interface phonesCalling {
    String makeCall(String number);
}
