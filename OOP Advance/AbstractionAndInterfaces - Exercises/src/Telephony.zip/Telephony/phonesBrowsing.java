package Telephony;


public interface phonesBrowsing {
    String startBrowse(String webAress);
}
