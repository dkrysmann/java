package Book;



public class Main {
    public static void main(String[] args) {
        Book firstBook = new Book("Animal Farm",2008,"Geo Milev","Ivan Vazov");
        Book secondBook = new Book("The Document in the case",2000,"Luben Karavelov");
        Book thirdBook = new Book("The document in the case",1996,"Svetlin Nakov");
        if(firstBook.compareTo(secondBook) > 0){
            System.out.println(String.format("%s is before %s",firstBook,secondBook));
        }else if(firstBook.compareTo(secondBook) < 0){
            System.out.println(String.format("%s is before %s",secondBook,firstBook));
        }else{
            System.out.println("Book are equal");
        }
    }
}
