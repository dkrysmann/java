package SayHello;


public class European extends BasePerson implements Person{

    public European(String name) {
        super(name);
    }
}
